from ultralytics import YOLO
import cv2

# Load two different models
helmet_model = YOLO(r"F:\MODELS\HELMET\best1.pt")   # <-- الاسم الجديد
fire_model   = YOLO(r"F:\MODELS\HELMET\best2.pt")   # <-- لو موجود في نفس الفولدر

cap = cv2.VideoCapture(0)  # webcam

while True:
    ret, frame = cap.read()
    if not ret:
        break

    # Run helmet model
    results1 = helmet_model(frame)

    # Run fire model
    results2 = fire_model(frame)

    # Draw results of both models
    for r in results1:
        frame = r.plot()

    for r in results2:
        frame = r.plot()

    cv2.imshow("Detection", frame)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()

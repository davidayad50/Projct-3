import cv2
from ultralytics import YOLO
import pygame
import threading
import time

# ----------------------------------------------------
# تهيئة الصوت
# ----------------------------------------------------
pygame.mixer.init()
pygame.mixer.music.load("alarm.mp3")  # ضع مسار ملف الصوت هنا

def start_alarm():
    if not pygame.mixer.music.get_busy():
        pygame.mixer.music.play(-1)  # -1 للتكرار المستمر

def stop_alarm():
    if pygame.mixer.music.get_busy():
        pygame.mixer.music.stop()

# ----------------------------------------------------
# تحميل الموديلات
# ----------------------------------------------------
helmet_model = YOLO(r"F:\MODELS\HELMET\best1.pt")    
fire_model   = YOLO(r"F:\MODELS\HELMET\fire_model.pt")  

# ----------------------------------------------------
# تشغيل الكاميرا والكشف
# ----------------------------------------------------
def detect_on_camera():
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("❌ فشل في تشغيل الكاميرا، جرب الفيديو...")
        cap = cv2.VideoCapture(r"F:\MODELS\HELMET\video.mp4")
        if not cap.isOpened():
            print("❌ الفيديو غير موجود أو غير قابل للفتح")
            return

    print("📷 Camera started — اضغط Q للخروج")

    fire_detected_start = None  # لتسجيل بداية اكتشاف النار
    alarm_active = False        # هل الإنذار شغال؟

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        # كشف الخوذة
        helmet_results = helmet_model(frame, conf=0.5, iou=0.3, stream=False)
        frame = helmet_results[0].plot()

        # كشف النار
        fire_results = fire_model(frame, conf=0.5, iou=0.3, imgsz=768, stream=False)
        frame = fire_results[0].plot()

        # إذا اكتشف النار
        if len(fire_results[0].boxes) > 0:
            cv2.putText(frame, " FIRE DETECTED!!", (50,50), 
                        cv2.FONT_HERSHEY_SIMPLEX, 1, (0,0,255), 3)
            
            if fire_detected_start is None:
                fire_detected_start = time.time()  # بداية العد

            # إذا النار موجودة لمدة 1 ثانية، نشغل الإنذار
            elif not alarm_active and time.time() - fire_detected_start >= 1:
                threading.Thread(target=start_alarm, daemon=True).start()
                alarm_active = True
        else:
            fire_detected_start = None
            if alarm_active:
                threading.Thread(target=stop_alarm, daemon=True).start()
                alarm_active = False

        cv2.imshow("Helmet & Fire Detection", frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    stop_alarm()
    cap.release()
    cv2.destroyAllWindows()

# ----------------------------------------------------
# تشغيل الكاميرا
# ----------------------------------------------------
detect_on_camera()
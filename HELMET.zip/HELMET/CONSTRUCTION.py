import cv2
from ultralytics import YOLO

# ----------------------------------------------------
# تحميل الموديلات
# ----------------------------------------------------
helmet_model = YOLO(r"F:\MODELS\HELMET\best1.pt")    
fire_model   = YOLO(r"F:\MODELS\HELMET\fire_model.pt")  
phone_model  = YOLO(r"F:\MODELS\HELMET\yolov8n.pt")  # الهاتف

# ----------------------------------------------------
# تشغيل الكاميرا والكشف
# ----------------------------------------------------
def detect_on_camera():
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("❌ فشل في تشغيل الكاميرا، جرب الفيديو...")
        cap = cv2.VideoCapture(r"F:\MODELS\HELMET\video.mp4")
        if not cap.isOpened():
            print("❌ الفيديو غير موجود أو غير قابل للفتح")
            return

    print("📷 Camera started — اضغط Q للخروج")

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        # كشف الخوذة والفيست
        helmet_results = helmet_model(frame, stream=False)
        frame = helmet_results[0].plot()  # الإطارات الافتراضية

        # كشف النار
        fire_results = fire_model(frame, stream=False)
        frame = fire_results[0].plot()

        # كشف الهاتف
        phone_results = phone_model(frame, conf=0.4)  # ضبط الثقة 0.4
        frame = phone_results[0].plot()

        # عرض النتيجة
        cv2.imshow("Helmet, Fire & Phone Detection", frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

# ----------------------------------------------------
# تشغيل الكاميرا
# ----------------------------------------------------
detect_on_camera()
